package com.app.motolife.URI;

public class API {
    public static final String API_URL = "http://192.168.0.16:8080/";
    public static final String API_CHECK = "http://192.168.0.16:8080/check";
    public static final String API_GET_LOCATIONS = "http://192.168.0.16:8080/getLocations";
    public static final String API_GET_UPDATE_USER_LOCATION = "http://192.168.0.16:8080/updateUserLocation";
    public static final String API_GET_UPDATE_USERNAME = "http://192.168.0.16:8080/getUsername";
    public static final String API_ADD_USER = "http://192.168.0.16:8080/addUser";
    public static final String API_SET_USER_TOKEN = "http://192.168.0.16:8080/setUserToken";


//    public static final String API_URL = "http://s1.ct8.pl:25500/";
//    public static final String API_CHECK = "http://s1.ct8.pl:25500/check";
//    public static final String API_GET_LOCATIONS = "http://s1.ct8.pl:25500/getLocations";
//    public static final String API_GET_UPDATE_USER_LOCATION = "http://s1.ct8.pl:25500/updateUserLocation";
//    public static final String API_GET_UPDATE_USERNAME = "http://s1.ct8.pl:25500/getUsername";
//    public static final String API_ADD_USER = "http://s1.ct8.pl:25500/addUser";
}
