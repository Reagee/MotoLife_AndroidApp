package com.app.motolife.Notifications;

public class MyResponse {
    public int success;
}
